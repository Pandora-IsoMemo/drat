collapse <- function(x) {
  paste0(x, collapse = ", ")
}
