#' @rdname shinyModule
#' @export
modelEstimationUI <- function(id, title = "") {
  ns <- NS(id)
  tabPanel(
    title = title,
    id = id,
    value = id,
    useShinyjs(),
    sidebarPanel(
      style = "position:fixed; width:23%; max-width:500px; overflow-y:auto; height:88%",
      width = 3,
      importUI(ns("modelImport"), label = "Import Model"),
      tags$br(),
      downloadModelUI(ns("modelDownload"), label = "Download Model"),
      hr(style = "border-top: 1px solid #000000;"),
      selectizeInput(ns("x"), "Independent (X) numeric variables", choices = NULL, multiple = TRUE, selected = NULL),
      selectizeInput(ns("xCategorical"), "Independent (X) categorical variables (optional)", choices = NULL, multiple = TRUE, selected = NULL),
      pickerInput(ns("y"), "Dependent (Y) variable", choices = NULL, multiple = FALSE, selected = NULL),
      sliderInput(ns("interactionDepth"), label = "Interaction depth",
                  min = 1, max = 3, step = 1, value = 1),
      sliderInput(ns("maxExp"), label = "Max exponent",
                  min = 1, max = 3, step = 1, value = 1),
      sliderInput(ns("inverseExp"), label = "Max inverse exponent",
                  min = 1, max = 3, step = 1, value = 1),
      checkboxInput(ns("intercept"), label = "Include intercept", value = TRUE),
      checkboxInput(ns("ar1"), label = "Include error autocorrelation term", value = FALSE),
      checkboxInput(ns("constraint"), label = "Constrain regression parameters to 1", value = FALSE),
      pickerInput(ns("mustInclude"), "Must include variables (optional)", choices = NULL, multiple = TRUE, selected = NULL, options = list(`actions-box` = TRUE)),
      pickerInput(ns("mustExclude"), "Must exclude variables (optional)", choices = NULL, multiple = TRUE, selected = NULL, options = list(`actions-box` = TRUE)),
      uiOutput(ns("invalidTerms")),
      selectizeInput(ns("xUnc"), "X numerical variables uncertainty (optional)", choices = NULL, multiple = TRUE, selected = NULL),
      selectizeInput(ns("xCatUnc"), "X categorical variables misclassification rate (optional)", choices = NULL, multiple = TRUE, selected = NULL),
      pickerInput(ns("yUnc"), "Dependent variable uncertainty (optional)", choices = NULL, multiple = FALSE, selected = NULL),
      radioButtons(ns("regType"), label = "Regression type", choices = c("linear", "logistic"), selected = "linear", inline = TRUE),
      sliderInput(ns("maxTerms"), label = "Max number of terms in formula",
                  min = 2, max = 200, step = 1, value = 8),
      conditionalPanel(
        condition = "input.constraint == false",
        checkboxInput(ns("scale"), label = "Scale variables to mean 0 and sd 1 (recommended)", value = TRUE),
        ns = ns
      ),
      checkboxInput(ns("imputeMissings"), label = "Impute missing values (multiple imputation via \"pmm\" method)", value = TRUE),
      sliderInput(ns("nChains"), label = "Number of MCMC chains",
                  min = 1, max = 8, step = 1, value = 3),
      sliderInput(ns("burnin"), label = "Number of burnin iterations",
                  min = 200, max = 3000, step = 100, value = 300),
      sliderInput(ns("iter"), label = "Number of MCMC iterations",
                  min = 100, max = 20000, step = 100, value = 500),
      actionButton(ns("run"), "Run model"),
      hr(style = "border-top: 1px solid #000000;"),
      h5("Model average (applicable after model run)"),
      selectInput(ns("wMeasure"), label = "Weighting measure for model averaging",
                  choices = c("Loo", "WAIC", "AIC", "AICc", "BIC", "logLik")),
      actionButton(ns("modelAvg"), "Create model average")
    ),
    mainPanel(
      width = 9,
      tagList(
        fluidRow(column(
          width = 3,
          shinyTools::dataExportButton(ns("exportAllModelOutput"),
                                       label = "Export summaries of all models")
        ),
        column(
          width = 9,
          helpText("Note: The export contains output of tabs 'Model Evaluation', 'Model Summary', 'Model Diagnostics', 'Durbin-Watson Test', 'Variable Importance'")
        )),
        tags$hr(),
        tabsetPanel(
          id = ns("modTabs"),
          modelEvaluationTab(ns("modelEvaluation")),
          modelSummaryTab(ns("modelSummary")),
          modelDiagnosticsTab(ns("modelDiagnostics")),
          modelPredictionsTab(ns("modelPredictions")),
          modelParametersTab(ns("modelParameters")),
          modelROCTab(ns("modelROC")),
          modelDWTab(ns("modelDW")),
          modelPredictionsCustomTab(ns("modelPredictionsCustom")),
          modelVariablesTab(ns("modelVariables")),
          modelVariablesImpTab(ns("modelVariablesImp"))
        )
      ))
  )
}

#' @rdname shinyModule
#' @export
modelEstimation <- function(input, output, session, data) {
  ns <- session$ns
  
  m <- reactiveVal()
  m_AVG <- reactiveVal()
  
  observe({
    updateSelectizeInput(session, "x", choices = names(data()), selected = "")
    updateSelectizeInput(session, "xCategorical", choices = names(data()), selected = "")
    updatePickerInput(session, "y", choices = names(data()), selected = "")
    updateSelectizeInput(session, "xUnc", choices = names(data()), selected = "")
    updateSelectizeInput(session, "xCatUnc", choices = names(data()), selected = "")
    updatePickerInput(session, "yUnc", choices = names(data()), selected = "")
  }, priority = 100) %>%
    bindEvent(data())
    
  allSummaries <- callModule(modelSummary, "modelSummary", model = m, modelAVG = m_AVG)
  allDiagnostics <- callModule(modelDiagnostics, "modelDiagnostics", model = m, nChains = input$nChains)
  allICData <- callModule(modelEvaluation, "modelEvaluation", model = m)
  callModule(modelPredictions, "modelPredictions", model = m, data = data, modelAVG = m_AVG)
  callModule(modelParameters, "modelParameters", model = m, modelAVG = m_AVG)
  callModule(modelPredictionsCustom, "modelPredictionsCustom", model = m, modelAVG = m_AVG)
  callModule(modelROC, "modelROC", model = m, data = data, modelAVG = m_AVG)
  allDW <- callModule(modelDW, "modelDW", model = m, data = data, modelAVG = m_AVG)
  callModule(modelVariables, "modelVariables", model = m, data = data, modelAVG = m_AVG)
  allVariableImportance <- callModule(modelVariablesImp, "modelVariablesImp", model = m, modelAVG = m_AVG)
  
  shinyTools::dataExportServer("exportAllModelOutput",
                               dataFun = reactive(function() {
                                 if (length(m()) == 0) return(NULL)
                                 # export list of dataframes:
                                 list(
                                   `Model Evaluation` = allICData(),
                                   `Model Summary` = allSummaries(),
                                   `Model Diagnostics` = allDiagnostics(),
                                   `Durbin-Watson Test` = allDW(),
                                   `Variable Importance` = allVariableImportance()
                                 )
                               }),
                               filename = "all_model_output")
  
  formulaParts <- reactive({
    if(!is.null(input$y) && !is.null(input$x) && input$y != "" && any(input$x != "")){
    xVars <- input$x
    xCategorical <- ""
    if(!is.null(input$xCategorical) && any(input$xCategorical != "")){
      xVars <- c(xVars, input$xCategorical)
      xCategorical <- input$xCategorical
    }

    FORMULA <- generateFormula(input$y, xVars) |>
      shinyTryCatch(errorTitle = "Generating formula failed")
    FORMULA <- createFormula(formula = FORMULA,
                  maxExponent = input$maxExp,
                  inverseExponent = input$inverseExp,
                  interactionDepth = input$interactionDepth,
                  intercept = input$intercept,
                  categorical = xCategorical) %>%
      shinyTryCatch(errorTitle = "Creating formula failed")
    
    ret <- gsub('[\n ]', '', strsplit(strsplit(as.character(FORMULA)[3], "~")[[1]], " \\+ ")[[1]])
    return(ret)
    } else {
      return("")
    }
  })
  
  invalidFormulaParts <- reactive({
    invalid_formula_terms(formulaParts(), data()) |>
      shinyTryCatch(errorTitle = "Checking formula terms failed")
  })
  
  output$invalidTerms <- renderUI({
    if (length(invalidFormulaParts()) == 0) return(NULL)
    
    tagList(
      div(class = "form-group shiny-input-container",
          tags$label(class = "control-label",
                     tagList(
                       "Automatically excluded terms ",
                       tags$i(
                         class = "glyphicon glyphicon-info-sign",
                         style = "color:#0072B2;",
                         title = paste(
                           "Terms are excluded from formulas if invalid:",
                           "- an exponent is applied on a non-numeric feature,",
                           "- a negative exponent is applied on a feature containing zero values.",
                           sep = "\n"
                         )
                       ),
                       " :"
                     )
          ),
          tags$br()
      ),
      tags$code(style = "display:block; margin-left: 1rem; margin-right: 1rem;",
                paste(invalidFormulaParts(), collapse = ", "))
    )
  })
  
  observe(priority = 40, {
    # auto-exclude invalid formula terms (inverse powers w/ zeros, or exponents on non-numeric)
    choices <- formulaParts()[!(formulaParts() %in% invalidFormulaParts())]
    
    # keep non-empty selection on changes
    updatePickerInput(session, "mustInclude",
                      choices = choices,
                      selected = keep_selected(input$mustInclude, choices))
    
    updatePickerInput(session,
                      "mustExclude",
                      choices  = choices,
                      selected = keep_selected(input$mustExclude, choices))
  })
  
  observe({
    if (length(m()) == 0) {
      shinyjs::disable(ns("modelAvg"), asis = TRUE)
    } else {
      shinyjs::enable(ns("modelAvg"), asis = TRUE)
    }
  }) %>%
    bindEvent(m(), ignoreNULL = FALSE)
  
  # MODEL DOWN- / UPLOAD ----
  modelsForDownload <- reactive({
    if (length(m()) == 0) return(NULL)
    
    allModels <- m()
    if (length(m_AVG()) != 0) {
      # add average model if exists
      allModels$models <- c(allModels$models, m_AVG())
    } 
    
    allModels
  })
  
  modelNotes <- reactiveVal(NULL)
  downloadModelServer("modelDownload",
                      dat = data,
                      inputs = input,
                      model = modelsForDownload,
                      rPackageName = config()[["rPackageName"]],
                      fileExtension = config()[["fileExtension"]],
                      modelNotes = modelNotes,
                      triggerUpdate = reactive(TRUE))
  
  uploadedModel <- importServer(
    "modelImport",
    importType = "model",
    ckanFileTypes = config()[["ckanModelTypes"]],
    ignoreWarnings = TRUE,
    defaultSource = config()[["defaultSourceModel"]],
    fileExtension = config()[["fileExtension"]],
    options = importOptions(rPackageName = config()[["rPackageName"]])
  )
  
  modelState <- reactiveVal(list())
  observe(priority = 200, {
    req(length(uploadedModel()) > 0)
    model <- uploadedModel()[[1]]
    state <- new_ShinyModelState(
      data = model$data,
      inputs = model$inputs,
      model = model$model,
      notes = model$notes
    )
    modelState(state)
  }) |>
    bindEvent(uploadedModel())
  
  observe(priority = 100, {
    req(length(uploadedModel()) > 0, inherits(modelState(), "ShinyModelState"))
    ## update data ----
    restoreData(modelState(), session, data, modelNotes)
  }) %>%
    bindEvent(uploadedModel())

  observe(priority = 70, {
    req(length(uploadedModel()) > 0, inherits(modelState(), "ShinyModelState"))
    ## update PRIMARY inputs ----
    # update will fail for those where e.g. choices are not yet ready
    restoreInputs(modelState(), session, validInputs = names(input))
  }) %>%
    bindEvent(uploadedModel())

  observe({
    req(length(uploadedModel()) > 0, inherits(modelState(), "ShinyModelState"))
    ## update model ----
    restoreModel(modelState(), session, m, m_AVG)
  }) %>%
    bindEvent(uploadedModel())
  
  observe({
    req(formulaParts())
    req(length(uploadedModel()) > 0, inherits(modelState(), "ShinyModelState"))
    ## update SECONDARY inputs ----
    # wait with update until e.g. choices are ready
    invalidateLater(250)  # allow for reactivity settling
    restoreInputs(modelState(), session, validInputs = get_secondary_input_names(modelState()))
    
    # clean up to free space
    modelState(list())
    uploadedModel(NULL)
  })
  
  # RUN MODEL ----
  observe({
    prepData <- data() %>%
      prepareData(in_x = input$x,
                  in_xUnc = input$xUnc,
                  in_y = input$y,
                  in_yUnc = input$yUnc,
                  in_xCategorical = input$xCategorical,
                  in_xCatUnc = input$xCatUnc,
                  in_regType = input$regType) %>%
      shinyTryCatch()

    req(prepData)
    FORMULA <- generateFormula(input$y, prepData$xVars)
    
    set.seed(1234)
    model <- withProgress({
      constrSelEst(
        formula = FORMULA,
        mustInclude = input$mustInclude,
        mustExclude = union(input$mustExclude, invalidFormulaParts()),
        maxExponent = input$maxExp,
        inverseExponent = input$inverseExp,
        interactionDepth = input$interactionDepth,
        categorical = prepData$xCategorical,
        ar1 = input$ar1,
        intercept = input$intercept,
        constraint_1 = input$constraint,
        data = prepData$dataModel,
        xUncertainty = prepData$xUnc,
        xCatUncertainty = prepData$xCatUnc,
        yUncertainty = prepData$yUnc,
        maxNumTerms = input$maxTerms,
        type = input$regType,
        scale = input$scale,
        chains = input$nChains,
        burnin = input$burnin,
        iterations = input$iter,
        shiny = TRUE,
        imputeMissings = input$imputeMissings
      ) %>%
        shinyTryCatch(errorTitle = "Running model failed")
    },
    value = 0,
    message = "Calculation in progess",
    detail = 'This may take a while')
    
    if (is.null(prepData$dataModel) || is.null(model)) {
      m(NULL)
      return()
    } 
    
    req(model)
    names(model$models) <- prepModelNames(model$models)
    # if(any(sapply(1:length(model), function(x) is.null(model[[x]])))){
    #   browser()
    # }
    fits <- withProgress({
      getModelFits(model$models, 
                   y = prepData$dataModel[, input$y], 
                   newdata = prepData$dataModel)
    }, value = 0.8, message = "Evaluate Models")
    
    m(list(models = model$models, fits = fits, dependent = input$y, variableData = model$variableData))
  }) %>%
    bindEvent(input$run)
  
  # RUN AVG MODEL ----
  observe({
    req(m())
    weights <- get_model_weights(m()$fits, measure = input$wMeasure) %>%
      shinyTryCatch()
    req(!is.null(weights))
    model_avg <- withProgress({list(
      get_avg_model(m()$models, weights) %>%
        shinyTryCatch()
    )}, value = 0, message = "Calculate model average")
    names(model_avg) <- paste0("model_average_", input$wMeasure)
    
    m_AVG(model_avg)
  }) %>%
    bindEvent(input$modelAvg)
  
  observe({
    req(m())
    if(m()$models[[1]]@type == "linear"){
      hideTab(inputId = "modTabs", target = "ROC")
    } else {
      showTab(inputId = "modTabs", target = "ROC")
    }
  })
}

keep_selected <- function(selected, choices) {
  if (is.null(choices) || length(choices) == 0) return(character(0))
  if (is.null(selected)) return(character(0))
  
  sel <- selected
  sel <- sel[sel %in% choices]                     # keep only valid choices
  sel <- if (length(sel)) sel else character(0)    # fall back if nothing left
  sel
}

# Returns the INVALID terms from `ret` based on:
# - any inverse power I(var^k) with k < 0 AND the column has zeros
# - any exponent I(var^k) where the column is non-numeric
# - any exponent I(var^k) where var is missing or exponent can't be parsed
invalid_formula_terms <- function(terms, dat) {
  if (length(terms) == 0) return(character(0))
  if (length(terms) == 1 && terms == "") return(character(0))
  if (is.null(dat) || nrow(dat) == 0) return(character(0))
  
  # Match I(<name> ^ <exponent>) with optional spaces; <name> = letters/digits/._ 
  # Exponent supports signs and decimals (e.g., -2, 2, 0.5, -0.5)
  pat <- "^I\\(([[:alnum:]_.]+)\\s*\\^\\s*([+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+))\\)$"
  
  m <- regexec(pat, terms)
  mm <- regmatches(terms, m)
  is_pow <- lengths(mm) > 0
  
  invalid <- rep(FALSE, length(terms))
  
  if (any(is_pow)) {
    bases <- vapply(mm[is_pow], function(x) x[2], character(1))
    exps  <- vapply(mm[is_pow], function(x) suppressWarnings(as.numeric(x[3])), numeric(1))
    idx   <- which(is_pow)
    
    for (j in seq_along(idx)) {
      v <- bases[j]
      k <- exps[j]
      x <- dat[[v]]
      
      invalid[idx[j]] <- is.na(k) || is.null(x) || !is.numeric(x) ||
        (k < 0 && any(x == 0, na.rm = TRUE))
    }
  }
  
  terms[invalid]
}

