conditionPlot <- function(id){
  paste0("!$('#", id, "').hasClass('shiny-output-error')")
}
