# CausalR 24.06.0

## New Features
- Documentation for package functions has been added.

# CausalR 24.06.0

## New Features
- The Shiny app has been refactored into a package, enabling the app to be launched within a Docker container.
- Dependencies on other packages have been defined.
