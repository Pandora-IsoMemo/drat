# Bpred App

### Access to online version:
- MAIN version: https://isomemoapp.com/app/bpred

### Help and installation Instructions:
- https://github.com/Pandora-IsoMemo/bpred/wiki

### Release Notes:
- see `NEWS.md`

### Folder for remote models
- for the MAIN version: https://github.com/Pandora-IsoMemo/bpred/tree/main/inst/app/predefinedModels
