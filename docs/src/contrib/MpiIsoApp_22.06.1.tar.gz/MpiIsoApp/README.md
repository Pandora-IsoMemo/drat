# Pandora & IsoMemo spatiotemporal modelling
Shiny App for spatiotemporal modelling develloped with the Pandora & IsoMemo initiatives.

## Deployment Versionen:

- https://isomemoapp.com/app/iso-memo-app
