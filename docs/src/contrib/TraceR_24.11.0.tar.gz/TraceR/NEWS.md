# TraceR 24.11.0

## Bug Fixes

- fix issue with zoom (#17)

# TraceR 24.09.0

## New Features

- check enviroment for download/import enviroment

# TraceR 24.09.0

## New Features

- option to sign the graph json file with a key pair
- option to download & import signed json
- deployment adjustments for shinyproxy

# TraceR 24.09.0

## Bug Fixes

- fix issue with zoom (#17)
- add logo as icon for the browser tab

# TraceR 24.07.0

## New Features

- option to import a graph from a json file from url, Pandora or file (#16)
- option to download all user inputs together with the graph as zip file (`.tracer`) (#16)
- option to import user inputs together with the graph from a zip file (`.tracer`) (#16)

# TraceR 24.06.1

## New Features

- adds possibility to download and upload graphs as json

# TraceR 24.04.1

## New Features

- add NEWS file
- add Pkgdown documentation workflow
- add R-cmd check workflow


# TraceR 23.11.1

## New Features

- first draft of TraceR

