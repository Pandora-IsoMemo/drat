#' UI function of toolsPanel module
#'
#' @param id module id
#'
#' @importFrom stats setNames
#'
toolsPanelUI <- function(id) {
  ns <- NS(id)
  sidebarLayout(
    sidebarPanel(
      width = 2,
      style = "position:fixed; width:15%; max-width:350px; overflow-y:auto; height:88%",
      importDataUI(ns("localData"), "Import Data")
    ),
    mainPanel(
      DT::dataTableOutput(ns("importedDataTable"))
    )
  )
}


#' Server function of toolsPanel module
#'
#' @param id module id
#' @inheritParams importDataServer
toolsPanelServer <- function(id, defaultSource = "ckan") {
  moduleServer(
    id,
    function(input, output, session) {
      testData <- reactiveVal(NULL)
      importedData <- importDataServer(
        "localData",
        customWarningChecks = list(reactive(checkWarningEmptyValues)),
        customErrorChecks = list(reactive(checkErrorNoNumericColumns)),
        ignoreWarnings = TRUE,
        defaultSource = defaultSource
        )

      observe({
        req(length(importedData()) > 0)
        d <- importedData()[[1]]
        testData(d)
      }) %>%
        bindEvent(importedData())

      output$importedDataTable <- renderDataTable({
        validate(need(
          !is.null(testData()),
          "Please import data."
        ))
        req(testData())
        testData()
      })
    })
}
