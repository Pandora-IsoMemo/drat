An app around deBInfer package.
