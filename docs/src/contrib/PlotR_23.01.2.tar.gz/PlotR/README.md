# PlotR

### Access to online version:
- BETA version: https://isomemoapp.com/app/plotr-beta

### Help and installation Instructions:
- https://github.com/Pandora-IsoMemo/plotr/wiki

### Release Notes:
- see `NEWS.md`
