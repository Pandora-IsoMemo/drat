# PlotR

### Access to online version:
- BETA version: https://isomemoapp.com/app/plotr-beta

### Help and installation instructions:
- https://github.com/Pandora-IsoMemo/plotr/wiki

### Release notes:
- see `NEWS.md`
