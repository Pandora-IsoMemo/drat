# PlotR

### Access to online version:
- beta version: https://isomemoapp.com/app/plotr-beta

### Help and installation Instructions:
- https://github.com/Pandora-IsoMemo/plotr/wiki

### Release Notes:
- https://github.com/Pandora-IsoMemo/plotr/blob/main/NEWS.md
