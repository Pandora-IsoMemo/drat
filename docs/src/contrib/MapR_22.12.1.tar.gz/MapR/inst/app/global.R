image_list <- read.csv("../app_data/image_list.csv")
