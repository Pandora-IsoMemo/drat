
shinyServer(function(input, output, session) {

  mapPanelServer(id = "map_panel")

})
