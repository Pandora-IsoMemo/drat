# MapR
An App to display temporal and temperature graphical files for Isomemo 
