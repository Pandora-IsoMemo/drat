# Pandora & IsoMemo spatiotemporal modeling
Shiny App for spatiotemporal modeling developed with the Pandora & IsoMemo initiatives.

### Access to online version:
- MAIN version: https://isomemoapp.com/app/iso-memo-app
- BETA version: https://isomemoapp.com/app/iso-memo-data-app-beta

### Help and installation Instructions:
- https://github.com/Pandora-IsoMemo/iso-app/wiki

### Release Notes:
- see `NEWS.md`
