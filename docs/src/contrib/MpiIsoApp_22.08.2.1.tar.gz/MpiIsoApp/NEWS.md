# MpiIsoApp development version

# MpiIsoApp 22.08.2.1

## Updates

- text update of the modeling tab for the _pandora / isomemo search app_ (#9)

# MpiIsoApp 22.08.2

## Enhancements
- when using _Pandora_ skin: updates of the UI in the _Import Data_ pop-up menu (#39)
- update label names in the _maps_ tab (#48)

## Bug fixes

- fixes in the modeling tab _AssignR_: (#46)
