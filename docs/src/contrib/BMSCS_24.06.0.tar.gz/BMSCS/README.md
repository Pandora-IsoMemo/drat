# BMSCS (constraint-estimation-app)

### Access to online version:
- MAIN version: https://isomemoapp.com/app/bmscs
- BETA version: https://isomemoapp.com/app/bmscs-beta

### Documentation and installation instructions:
- https://pandora-isomemo.github.io/BMSCS/
- https://github.com/Pandora-IsoMemo/bmscs/wiki

### Release notes:
- see `NEWS.md`

### Folder for online models:
- [`inst/app/predefinedModels`](https://github.com/Pandora-IsoMemo/bmsc-app/tree/main/inst/app/predefinedModels)
