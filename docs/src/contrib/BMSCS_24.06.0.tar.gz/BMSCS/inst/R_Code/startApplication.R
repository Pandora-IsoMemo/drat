library(BMSCS)

startApplication(port = 3838)
