# DSSM 26.04.1

## Updates
- _Interactive map export_: added a notice about third-party basemap licenses/terms and attribution requirements, and added a corresponding note to `README.md`.

# DSSM 26.04.0

## Updates
- Added rnaturalearth attribution in `RScripts/update_maps.R`, and added an acknowledgments section in `README.md`.
- Appended a “Third-Party Licenses” section (including MIT license text for rnaturalearth) to `LICENSE.md`.
- Added a recommended citation for mclust in `README.md`.

# DSSM 26.03.2

## Updates
- Refactored the summarise() call in findDuplicates() to remove the deprecated unnamed column expression, fixing compatibility with recent dplyr versions.

# DSSM 26.03.1

## Updates
- Replaced `pryr::mem_used()` with a new helper based on gc() and `pryr::object_size()` with utils::object.size().
- Removed `pryr` dependency (not available on CRAN anymore).

# DSSM 26.03.0

## Updates
- Removed the deprecated fileExtension argument from `DataTools::importServer()` calls across model/map modules.
- Added additional logging around 3D model execution.
- Adjusted variance-spline construction in `mgcv::smoothCon()` to improve smoothing stability (#296).

# DSSM 26.01.1

## Updates
- Refactored colour palette handling by introducing a centralized, reusable colour palette module (#293).
  - Replaced duplicated UI and server logic across multiple visualisation modules.
  - Added support for single-colour, multi-colour, white-start, and diverging palettes.
  - Updated map plotting functions to use the new palette infrastructure.

# DSSM 26.01.0

## Updates
- Added logging of object sizes also to the modelling tabs _KernelR, KernelTimeR, SpreadR AssignR_ (#206)

## Bug Fixes
- Fixed hidden UI for setting the center estimates in _KernelTimeR_ time course plots (#292)
- Fixed decimal-place settings for axis labels: x and y axes now have separate inputs, with an improved default for the y axis (1 decimal place) to prevent rounding issues (#292)

# DSSM 25.12.0

## Bug Fixes
- Fixed an issue where date columns were parsed as character instead of numeric, causing errors when 
  calculating date ranges and means in the UI (#289).
- Added logging of object sizes for easier debugging of memory issues. (#289)
- Extracted common code into helper functions to reduce code duplication.

# DSSM 25.10.0

## New Features
- BibTeX Citation Formatting:
  Added support for formatting and exporting BibTeX citations. Users can now select citation styles (APA, Chicago, Harvard) and output formats (text, HTML, LaTeX, etc.) for BibTeX entries. New UI modules allow configuration of citation styles and columns, and citation export supports user-selected formatting.

# DSSM 25.09.1

## New Features
- _Modeling tabs - TimeR_: option to export a series of geotiff files for each selected time slice (#286)

# DSSM 25.09.0

## Bug Fixes
- _Interactive Map_: fixed brackets in export module (#284)

# DSSM 25.08.0
 
## New Features
- _Modeling tabs_: Added a "Show borders" toggle in the right sidebar, below "Show map grid". (#281)

## Updates
- _Map layers_: refactored to S3 (MapLayers class + per-layer methods); replace addMapLayers() with plot(new_MapLayers(...)).

# DSSM 25.07.3

## New Features
- _Interactive Map_: Added option to shift the _North Arrow_ or the _Scale_ to a _custom_ latitude
  and longitude position (#275)

# DSSM 25.07.2

## Updates
- export of time series plots: fixed bug (#268) 
  - Added asynchronous creation of single plots for a time series. Now, users must press
    "Generate Plot Files" before the download of a series of plots.
  - Switched to using the **`gifski`** package for animated GIF creation, replacing the `magick` package,
    which crashed when handling a large number of input images.

# DSSM 25.07.1

## Bug Fixes
- _Estimates for (Bayesian) TimeR models_: Fixed a sign-error in the Metropolis Hastings 
  Algorithm for the date uncertainty
  - This bug could lead to overly wide estimate ranges (#276)

# DSSM 25.07.0

## Bug Fixes 
- reduced buffer that is added to the range of the default scale for the estimates (#276)

# DSSM 25.06.0

## New Features
- added logging of _high_ and _critical_ memory usage when running DSSM in a local Docker container (#206)

# DSSM 25.05.1

## Updates
- _interactive Map_:
  - added a preview to the export modal, allowing users to check the effect of width and height
    settings before exporting the map (#267)
  - option to set the _North Arrow_ and _Scale Bar_ size (#267)
  - Renamed input "Fit boundaries" to "Zoom into boundaries" to more clearly indicate the option 
    for zoom fine-tuning (#267)

## Bug Fixes
- _interactive Map_:
  - removed maps from the dropdown that can no longer be accessed (#267)
  - fixed issue with scrolling bar in the window list (#267)

# DSSM 25.05.0

## Updates
- _interactive Map_: 
  - _Map Settings_: separate checkbox for "Fixed" point aesthetics (#267)
  - option to close and open the view of the _Map settings_ and _Statistics_ panels (#267)

## Bug Fixes
- _interactive Map export_:
  - switch from deprecated phantomjs to chromium for webshot2 (#267)
  - fix issue with PDF export of maps
- _modelling tabs_:
  - update all maps to fix an issues with the plotting of maps for different ranges (#270)

# DSSM 25.04.0

## Updates
- use most recent shinyTools version with smaller header logos

# DSSM 25.03.1

## Updates
- skip large data tests in CI and add large test data to the `.Rbuildignore`

# DSSM 25.03.0

## Updates
- shift content of the help popup into a new vignette "How to use DSSM"
- update links in ReadMe and in app header
- reduce package size by optimizing test data and add example files to the `.Rbuildignore`

# DSSM 25.01.0

## Bug Fixes
- remove `Cairo::CairoSVG` since it did not help
- clip map layers to ranges xlim, ylim before adding them to the map (#259)
- handle the case of the _ocean_ layer where geometries are added implicitly
  - cannot use intersection of the map with a bounding box
  - the layer must be subtracted from the bounding box
  - for pacific centering xlim must be split into parts smaller and larger zero

# DSSM 24.12.1

## Bug Fixes
- use `Cairo::CairoSVG` for export of `.svg` plots (#259)

# DSSM 24.12.0

## Updates
- _Modeling tabs_: updated the process of map centering (#248)
  - now the Pacific center is at 180° longitudes instead of 160° longitudes
  - old maps for Pacific were replaced by new maps
  - the code to create plots had to be refactored significantly

# DSSM 24.10.1

## Bug Fixes
- fix issue with penalty parameter when using Bayesian Modelling (#251)

# DSSM 24.10.0

## New Features
- _KernelR_ + _KernelTimeR_: New restriction factor input for tclust clustering (#204)

# DSSM 24.09.2

## New Features
- _Centerpoint estimates_: Radius input is now hidden if the center coordinates are not set (#252)

# DSSM 24.09.1

## New Features
- _KernelR_ + _KernelTimeR_: New option to adjust smoothness of kernel density estimator

# DSSM 24.09.0

## Bug Fixes
- fix issue with failing modeling for "Smooth Type" = "planar" with 'number of spatial basis functions' input (#247)

# DSSM 24.08.5

## New Features
- Adds tclust as clustering method in KernelR and KernelTimeR (#204)

## Bug Fixes
- solves issue with the plotting and export of cluster data in KernelR

# DSSM 24.08.4

## New Features
- _OperatoR_: New plot option ("estimation type"): 'Significance (Overlap)': Shows which non-significant overlap in difference maps
  
# DSSM 24.08.3

- Adds info button with rule of thumb information on selection of number of basis functions to 
  "AverageR", "TimeR" and "SpreadR" tabs (#236)

# DSSM 24.08.2

## New Features
- _Cost Surface and least-cost path for SpreadR_:
  - Estimate cost surface and shortest path using the gdistance package

# DSSM 24.08.1

## Bug Fixes
- fixes cluster ids being non continuous in some cases (#238)

# DSSM 24.08.0

## New Features
- adds option to TimeR and KernelTimeR to download a zipm file that can be uploaded in MapR (#203)

# DSSM 24.06.0

## New Features
- replace `rgeos::gCentroids()` with `sf::st_centroid()` because of retired packages `rgeos` and
  `rgdal` (#228)
- Renaming of the Package
- R-CMD check workflow
- pkgdown Documentation

# MpiIsoApp 24.05.7

## Bug Fixes
- _LocateR_: fix pch value when creating a probability map which caused a warning (#224)
- _Saved maps_: fix issue when thumbnail was missing in former uploaded saved maps

# MpiIsoApp 24.05.6

## New Features
- _Saved maps_:
  - option to download a zip file with all plots in a chosen format (#2)
  - removing option to download saved maps with the current model object, since files become too large
    and upload takes too long

# MpiIsoApp 24.05.5

## New Features
- _Saved maps_: export and import of saved maps is now included within the features to down- and
  upload models (#2)
  - optionally, the list of saved models can be downloaded
  - upload checks for a list of saved maps and loads it, if it is available

# MpiIsoApp 24.05.4
## Bug Fixes
- fix issue with warning whenever using a bayesian model (#199)

# MpiIsoApp 24.05.3

## Bug Fixes
- fix for the spread model which was not running if two dates were specified (#218)
- fixes the case when we have missing longitude or latitude data in the data set (#219)

# MpiIsoApp 24.05.2

## New Features
- _Interactive Map_: 
  - possibility of selecting a specific point colour when no point colour variable was 
    selected ("Fixed" point colour) (#174)
  - button to apply settings for the style of points

# MpiIsoApp 24.05.1

## New Features
- define the center of coordinates before modelling in the _Modeling_ tabs. This shifts data to
respective longitudes (#196)
  - if "0th meridian" longitudes are transposed to the range (-180, 180)
  - if "180th meridian" longitudes are transposed to the range (0, 360)
- a vignette was added to the package describing features for the processing of coordinate data (#196)

# MpiIsoApp 24.05.0

## New Features
- _OperatoR tab_:
  - option to create contour maps from saved maps (#202)

# MpiIsoApp 24.04.1

## Bug Fixes
- fix logic to filter location marks for time slices (#200)

# MpiIsoApp 24.04.0

## New Features
- preview of input data in modeling tabs

## Bug Fixes
- fix crashing of map plotting when time is out of range (#207)
- fix wrong color data for centroids (#205)

# MpiIsoApp 23.12.1

## New Features
- New option to create elevation maps in OperatoR as well as custom maps
- Option to weight by map in LocatoR including options (e.g. weight by altitude/elevation map)
- Create custom map from x-y-z data from file in OperatoR 
- Option to create probability maps in LocateR independently

# MpiIsoApp 23.12.0

## New Features
- _Import of models from Pandora_: 
  - display of "About" information that is associated to a selected Pandora Repository

## Bug Fixes
- _Import of models from Pandora_: 
  - an error message occurred when trying to load a model from pandora.
  - fix: adding the missing download of the zip file from the url before unpacking the zip

# MpiIsoApp 23.10.3

## Bug Fixes
- fix issue with missing location marks in TimeR and TimeRKernel (#193)

# MpiIsoApp 23.10.2

## Bug Fixes
- prevent display of data on different "leaflets" by adding the option to choose an Atlantic or a
  Pacific map center (#173)

# MpiIsoApp 23.10.0

## New Features
- Create new map option moved to OperatoR tab
- Batch option to provide multiple points to create new map (csv or excel file for upload)
- Option for specific average radius for each row in batch input for operatoR

# MpiIsoApp 23.09.1

## New Features
- _Import of models_:
  - option to import models from Pandora platform

# MpiIsoApp 23.07.1

## New Features
- _Missing Values Imputation AssignR_: Multiple imputation for AssignR using the "mice" package

# MpiIsoApp 23.06.4

## New Features
- _Modeling tabs_: The text for center point estimates 
  - now contains the underlying grid length (#169)
  - can be hidden again by removing inputs for latitude and longitude

## Updates
- removed recalculation of predictions when changing the latitude or longitude for center estimates

# MpiIsoApp 23.06.3

## Bug Fixes
- _Export of time series_: 
  - fixes export of pdf files together with a .gif (#107)
  - now .gif files are always based on jpeg files, for .gif no conversion from pdf is required anymore

# MpiIsoApp 23.06.2

## New Features
- _Tab Data_: new input to select an ontological schema, e.g. the "IsoMemo" schema (#102)

# MpiIsoApp 23.06.1

## Updates
- add spinner to indicate that app is initializing
- optimize loading of tabs when initializing
- use DataTools 23.06.1 to fix issues with importing data without internet connection (#157)

# MpiIsoApp 23.06.0

## Bug Fixes
- _Interactive Map_:
  - fix option to use a fixed point colour (#161)

# MpiIsoApp 23.05.4

## Updates
- option in KernelTimeR to choose between temporal group or spatial cluster

# MpiIsoApp 23.05.3

## New Features
- _Export of time series_: optionally add a gif file or only export a gif (#107)

# MpiIsoApp 23.05.2

## New Features
- _Interactive Map_: 
  - map types are grouped by having borders or names (#133)
  - option to add more maps from different providers: https://leaflet-extras.github.io/leaflet-providers/preview/

# MpiIsoApp 23.05.1

## Updates
- _Interactive Map_: add option "[Fixed]" for point size, colour and symbol (#13)

# MpiIsoApp 23.04.3.3

## Bug Fixes
- apply bug fix from main on beta (#142)

# MpiIsoApp 23.04.3.2

## Bug Fixes
- apply bug fix from main on beta (#122)

# MpiIsoApp 23.04.3

## Updates
  - removing the calculation of clusters for unfiltered data
  - renaming columns in the excel export
  - renaming "Number of clusters (optional)" to "Possible range for clusters"
  - increasing the maximum number of clusters from 20 to 50 for mclust
  - add option to show spatial centroids

# MpiIsoApp 23.04.2

## New Features
- _Interactive map_: 
  - option to set the symbol dependent on values of a character column (#13)
  - show/hide legends for size (if a variable is used) and symbols 

## Updates
- optimized behavior of updating data and show/hide legends on the interactive map

# MpiIsoApp 23.04.1.10

## Bug fixes
- fixes an error when trying to reach the API without internet connetcion (#157)

# MpiIsoApp 23.04.1.7

## Bug Fixes
- fix case if date columns are not numeric (#110)

# MpiIsoApp 23.04.1.6

## Bug Fixes
- add default API_BASE_URL (#142)

# MpiIsoApp 23.04.1.5

## Bug Fixes
- fix bug in conversion of lat/long when using import in modeling tabs (#122)

# MpiIsoApp 23.04.1

## New Features

- _Model tabs_: Option to load a model
  - download a model (all user inputs, data and/or the model output) as a .zip file
  - upload online models that are stored in github
  - upload local models that were downloaded in a past session
  - check if the model to be uploaded comes from the active tab

# MpiIsoApp 23.03.6

## New Features

- Adds mclust as new clustering option for KernelR and KernelTimeR
- Adds columns to excel for KernelTimeR: centroid full data, centroid sliced data, centroid temporal data

## Bug Fixes

- Unifies colors for clustering map and clustering plot within KernelTimeR
- Fixing crash in mapSim, mapDiff and kernel plotting function after updates regarding categorical
target/dependent variable

# MpiIsoApp 23.03.5

## Updates

- Show type of user created maps (#19)

# MpiIsoApp 23.03.4

## Updates

- Categorical target/dependent variable option for AverageR/TimeR models. This follows a 1vsall approach using logistic regression, which in the Bayesian case is performed using a Polya-Gamma latent variable during Gibbs-sampling (https://arxiv.org/abs/1205.0310)

# MpiIsoApp 23.03.3

## Updates

- Option to decide whether to keep the first or last duplicate row.

# MpiIsoApp 23.03.2

## Updates

- Option to set max number of characters to be displayed in the table.

# MpiIsoApp 23.03.1

## Updates

- _Import Data_ module in the tab _Query with SQL_: confirm using GPT3 before option to upload a key

# MpiIsoApp 23.02.4

## Updates

- _Import Data_ module in the tab _Query with SQL_: option to use GPT3 for creation of SQL queries

# MpiIsoApp 23.02.3

## Updates

- Option to decide if column with duplicate rows is added
- Option to ignore spaces during duplicate detection
- Option to specify a string that is used for duplicate detection

# MpiIsoApp 23.02.2

## Updates

- the _Import Data_ module was now integrated into the modeling tabs _AverageR_, _TimeR_,
  _SpreadR_, _KernelR_, _KernelTimeR_, and _AssignR_ (#91, PR #98)
  - applicable when "Upload file" is selected under "Data source" in the left sidebar

# MpiIsoApp 23.02.1

## New features

- A new button "detect duplicates" has been added that opens a pop-up where duplicates can be detected and removed from the dataset.

# MpiIsoApp 23.01.4.1

## Bug Fixes

- inputs for latitude and longitude were falsely hidden for time plots in TimeR and KernelTimeR (#94)

# MpiIsoApp 23.01.4

## Updates

- when using _Pandora_ skin:
  - the _Import Data_ module is now imported from the new package IsoAppTools (#91, PR 92)
  - now changes of functionality
  - all redundant code was removed

# MpiIsoApp 23.01.3

## New features

- when using _Pandora_ skin, in _Import Data_:
  - option to use SQL queries to prepare or combine data before import (#37, PR #89)
    - use in-memory tables and columns
    - provide and apply a query
    - preview and accept the result
    
## Bug Fixes

- fixed bug when importing data with no numeric columns:
  - data was not displayed because no lat/long columns were found
    
# MpiIsoApp 23.01.2

## New features

- under Saved/Create Maps tab (#19)
  - option to add a square
  - update of the UI

- fixed sidebars with auto scroll in all tabs (#4)

# MpiIsoApp 23.01.1

## New features

- interactive map: 
  - option to assign colour of symbol by selecting a certain data column (#13)
    - choose a colour palette
    - reverse colours
  - option to assign size of symbol by selecting a certain data column (#13)
    - set a factor to adjust the size
    - if no column is selected, the factor sets the general point size
  - option to adjust opacity

# MpiIsoApp 22.12.4

## New features

- when using _Pandora_ skin, in _Import Data_:
  - option to prepare data before import or merge
    - rename columns
    - join columns
    - split columns
    - delete columns
  - option to merge two data tables before import (#37)
    - optionally select all common columns
    - specify the merge operation
    - apply the merge for reviewing and error checking
    - accept the merged file to finally import it into the app
  - checks for correct column names in file imports
  - update column names of files if naming conflicts
  - new tests

## Updates

- disable accept button(s) by default in _Import Data_

# MpiIsoApp 22.12.3.1

## Bug Fixes

- inputs for latitude and longitude were falsely hidden for time plots in TimeR and KernelTimeR (#94)

# MpiIsoApp 22.12.3

## Updates

- _export of plots_ after modelling: hide option to create a time series for
_Time Course_ plot type (#8)

## Bug Fixes

- fix naming issue when data contains columns exactly named "latitude" or "longitude"
  - columns will be renamed if coordinate conversion fails

# MpiIsoApp 22.12.2

## Updates

- add notification if conversion of lng/lat was successful (#67)

## Bug Fixes

- fix reset of lng/lat columns when switching coord formats

# MpiIsoApp 22.12.1

## Bug Fixes

- fix export of time plot as time series in TimeR and KernelTimeR (#8)

# MpiIsoApp 22.11.1

## Updates

- extract z scale settings ("Estimation type", "Show estimates", Min/Max range, "Restrict range")
into their own module
- new module zScale applied in the modelling tabs: _AverageR_, _KernelR_, _TimeR_, _KernelTimeR_,
_SpreadR_, _OperatoR_, _LocateR_
- switch the title for min/max range dependent on the "Plot type"

## Bug fixes

- fix update of min/max values after removing a restriction (min/max values had been overwritten
before, that is, removing a restriction did not reset min/max values) (#27)
- remove duplicated re-rendering of the map when changing "Estimation type" or restricting the range
- update choices of "Estimation type" when switching the "Plot type" in _TimeR_ since some types
are not implemented for "Time course"
- debounce inputs for min/max range to prevent re-rendering of the map when typing min/max values 

# MpiIsoApp 22.10.3

## Updates

- new UI to specify the section of maps of modelling tabs (_AverageR, TimeR, SpreadR, KernelR,
KernelTimeR, OperatorR, LocateR_)
  - dynamically use the buttons up, down, center, ...
  - apply a button "Set (Time and) Map Section" to set
    - time (only for _TimeR_ and _KernelTimeR_),
    - zoom in degrees of longitude, or
    - lat/long of upper left corner
- new modules that encapsulate the functionality behind the new UI
- applying the new modules in all modelling tabs and removing copy-paste code

## Bug fixes

- removes the slow **automatic** updates for inputs of time and zoom (#8)

# MpiIsoApp 22.10.2

## Bug fixes

- fixing the point radius changing with latitude, now set radius in pixel (#44)

# MpiIsoApp 22.10.1

## New features

- specify the sheet of an xlsx/xls file in the import dialog
- new button "Center Map" in the _Interactive map_ section that centers the map at the mean 
longitude and latitude of the displayed data

## Enhancements

- for Pandora skin: set default Latitude and Longitude columns after data load if match was 
found (#67)
  - note: the default format is "decimal degrees", here we still apply the check for numeric columns

## Bug fixes

- fix failing of import of xlsx files with sheets (-> option to select the sheet)
- fix missing columns in the selection of `Longitude` and `Latitude` if `Coordinate format` was not
equal "decimal degrees" (#62)
- fix in the removal of points on the interactive map after using filters (#63)

# MpiIsoApp 22.09.3

## New features

- export a time series of _spatio-temporal-average_ plots in the selected file format condensed
into a zip file

# MpiIsoApp 22.09.2

## New features

- option to adjust the format of the axes in time course plots (decimal places and number of labels)
- option to adjust the decimal places of the center estimates for mapType == "Map" or "Spread"

# MpiIsoApp 22.09.1

## Enhancements

- In the _Modelling_ tab under _TimeR_ and _KernelTimeR_: new (numeric) input field for the
`Time selection` in addition to the slider input `Time selection`

# MpiIsoApp 22.08.2.1

## Updates

- text update of the modeling tab for the _pandora / isomemo search app_ (#9)

# MpiIsoApp 22.08.2

## Enhancements

- when using _Pandora_ skin: updates of the UI in the _Import Data_ pop-up menu (#39)
- update label names in the _maps_ tab (#48)

## Bug fixes
- fixes in the modeling tab _AssignR_: (#46)
