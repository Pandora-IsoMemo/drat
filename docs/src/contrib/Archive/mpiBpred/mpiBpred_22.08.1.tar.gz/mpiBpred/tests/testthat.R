library(testthat)
library(mpiBpred)

test_check("mpiBpred")
