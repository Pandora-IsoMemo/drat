# MpiBpred app development version

## MpiBpred 22.11.1

### New Features
- save inputs when downloading a model (#1)
- update all input fields after uploading a model (#1)

### Updates
- also update table of measures after upload of a model (#13)
