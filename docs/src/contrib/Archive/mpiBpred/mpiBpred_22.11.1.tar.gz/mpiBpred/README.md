# Bpred

Access app: https://isomemoapp.com/app/bpred

Release Notes: https://github.com/Pandora-IsoMemo/bpred/blob/main/NEWS.md
