library(testthat)
library(Bpred)

test_check("Bpred")
