## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(IsomemoData)
getDatabaseList() # returns a list of database names linked to the API call

## ----explore data-------------------------------------------------------------

df = getData(db="IntChron",category = "Location")
head(df)

## ----all data-----------------------------------------------------------------
ALL_DATA = getData()
print(nrow(ALL_DATA)) # check how many rows
levels(ALL_DATA$source) # check all the database sources are there

## ----analysis-----------------------------------------------------------------
library(ggplot2)
library(maps)

worldmap = map_data('world') # load in background map

df = na.omit(df) # omit all NAs

ggplot() + 
  geom_polygon(data = worldmap, 
                        aes(x = long, y = lat,group=group),
                        fill = 'gray90', color = 'black') +
  theme(plot.margin = unit(c(5, 5, 10, 10), "cm"))+

  theme_void() + 
  # now input all the major data points from the databases IntChron
  geom_point(data = df, 
             aes(x = as.numeric(longitude), 
                 y = as.numeric(latitude)), color = 'red') +
  theme(title = element_text(size = 12))

## ----descriptives-------------------------------------------------------------
getDatabaseList()

df1 = getData('LiVES')
summary(df1)

## ----hist---------------------------------------------------------------------
hist(df1$d15N)

## ----regression---------------------------------------------------------------
df1 <- na.omit(df1)
lm(d13C~d15N,data=df1)


