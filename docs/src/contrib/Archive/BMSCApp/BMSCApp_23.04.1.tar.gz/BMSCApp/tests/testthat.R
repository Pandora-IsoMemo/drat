library(testthat)
library(BMSCApp)

test_check("BMSCApp")
