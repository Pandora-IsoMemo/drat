library(testthat)
library(MpiIsoApp)

test_check("MpiIsoApp")
