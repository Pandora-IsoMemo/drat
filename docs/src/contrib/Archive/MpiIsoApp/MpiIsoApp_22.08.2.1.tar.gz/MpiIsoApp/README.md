# Pandora & IsoMemo spatiotemporal modeling
Shiny App for spatiotemporal modeling developed with the Pandora & IsoMemo initiatives.

## Deployment Versionens:

- https://isomemoapp.com/app/iso-memo-app
- https://isomemoapp.com/app/iso-memo-data-app-beta
