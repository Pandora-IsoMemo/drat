# testthat::test_that("function addFormattedAxis", {
#   # only test manually, no expect value available
#   #
#   plot(data.frame(x = c(1.2435, 4.575, 7.4324), y = c(2.4534, 4.5474, 8.423)), xaxt = "n", xlim = c(0, 10))
#   addFormattedAxis(axis = "x", min = 0, max = 10, nLabels = 6, decPlace = 3)
#
#   plot(data.frame(x = c(1.2435, 4.575, 7.4324), y = c(2.4534, 4.5474, 8.423)), xaxt = "n", xlim = c(0, 10))
#   addFormattedAxis(axis = "x", min = 0, max = 10, nLabels = 6, decPlace = 0)
# })
