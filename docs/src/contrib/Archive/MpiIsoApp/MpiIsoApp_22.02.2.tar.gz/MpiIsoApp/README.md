# iso-app
Shiny App für Isotopen Datenbank (Position 3)

## Deployment Versionen:

- https://isomemoapp.com/app/iso-memo-app
