library(PEITHO)

PEITHO::startApplication(launch.browser = TRUE)
