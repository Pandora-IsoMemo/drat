library(testthat)
library(PEITHO)

test_check("PEITHO")