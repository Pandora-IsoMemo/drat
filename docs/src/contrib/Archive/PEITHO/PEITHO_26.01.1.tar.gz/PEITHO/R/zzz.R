.onLoad <- function(libname, pkgname) {
  PEITHO:::init_logging()
}