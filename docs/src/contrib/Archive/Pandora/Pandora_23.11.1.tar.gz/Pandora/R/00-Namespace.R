#' @import curl
#' @importFrom dplyr arrange bind_rows distinct filter
#' @importFrom jsonlite fromJSON
#' @importFrom magrittr %>% 
#' @importFrom rlang .data
NULL