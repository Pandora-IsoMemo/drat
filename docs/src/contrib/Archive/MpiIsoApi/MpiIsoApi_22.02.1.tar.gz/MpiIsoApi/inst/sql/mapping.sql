SELECT * FROM `mapping`;
