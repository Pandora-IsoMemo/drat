select * from `data` limit 0, 1;
select distinct(`variable`) from `extraCharacter`;
select distinct(`variable`) from `extraNumeric`;
