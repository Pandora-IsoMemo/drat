# ChangeR v.0.01
Author: Jianyin Roachell, Ricardo Fernendes, PhD.
Affiliation: Max Planck Gesellschaft, Geoanthropology

Bringing Python Packages Ruptures and MCP R package into a User Friendly Interface.

ChangeR will consist of a series of algorithms for point change detection that will eventually be made available via a user-friendly interface. ChangeR algorithms are based on the Python Package Ruptures and MCP R package.

An available ChangeR algorithm (v 0.01) is based on MCP and was designed to identify isotopic point changes in human tooth sections.

