# ChangeR 24.11.0

## New Features
- first version of the shiny app for change-point detection based on modules extracted from OsteoBioR 24.10.0 (#1)
