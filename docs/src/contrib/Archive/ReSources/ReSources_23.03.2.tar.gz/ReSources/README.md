# ReSources

### Access to online version:
- MAIN version: https://isomemoapp.com/app/resources
- BETA version: https://isomemoapp.com/app/resources-beta

### Folder with example models
- `inst/app/predefinedModels`

### Help and installation instructions:
- https://github.com/Pandora-IsoMemo/resources/wiki

### Release notes:
- see `NEWS.md`

