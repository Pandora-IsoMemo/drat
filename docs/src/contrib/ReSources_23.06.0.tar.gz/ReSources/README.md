# ReSources

### Access to online version:
- MAIN version: https://isomemoapp.com/app/resources
- BETA version: https://isomemoapp.com/app/resources-beta

### Help and installation instructions:
- https://github.com/Pandora-IsoMemo/resources/wiki

### Release notes:
- see `NEWS.md`

### Folder for online models
- [`inst/app/predefinedModels`](https://github.com/Pandora-IsoMemo/resources/tree/main/inst/app/predefinedModels)
