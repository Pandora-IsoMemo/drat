# llmModule 25.04.0

## New features

- added method to format the API response (#1)

# llmModule 0.1.0

## New features

- first draft of the llm module

