# Pandora 26.08.4

## Updates
-  Skipped `getData()`, `loadData()`, and `loadText()` tests on transient network failures, such as HTTP 429 rate limits and temporary connectivity issues.

# Pandora 26.08.3

## Updates
- Improved robustness of API-dependent tests by skipping on transient network failures (for example HTTP 429 rate limits and temporary connectivity issues)

# Pandora 26.08.2

## Updates
- Improved error handling and messages when the Pandora API is not accessible.

# Pandora 26.08.1

## Updates
- added a new loadText() helper to the Pandora R package to load plain-text resources (local files or remote URLs), including optional line-collapsing, and refactored remote-download handling to be reusable across data loaders.

# Pandora 26.08.0

## Bug Fixes
- fixed API access issues by setting a custom User-Agent header for API requests and resource downloads

# Pandora 24.02.0

## Updates
- catch issue if resources are missing in tests
- automate documentation

# Pandora 23.12.0

## Features
- new parameters for the function `getRepositories()` to select and rename the columns of the result
- vignette and documentation were added to the package

# Pandora 23.11.2

## Features
- new function `getData()` was added, which enables data retrieval
- the function `dataOption()` returns a list of options for `utils::read.csv()` or 
  `openxlsx::read.xlsx()` or `readxl::read_excel`, respectively, that can be passed to `getData()`

# Pandora 23.11.1

## Updates
- export of `callAPI()` function, update of documentation

# Pandora 23.11.0

## Features
The main function that facilitate the data retrieval and aggregation from the API is:

 - `getData()` (_under development_)

The following are its sub-functions contained in this package: 

  - `getNetworks()` returns a data.frame containing available networks (groups in CKAN terminology)
    - optional filtering of names for a given string
  - `getRepositories()` returns a data.frame containing available repositories 
    - all or those within a specific network
    - optional filtering of meta information for a given string
  - `getFileTypes()` returns a data.frame containing available file types of a repository
    - all or those within a specific network or within a specific repository
    - optional filtering of meta information for a given string
  - `getResources()` returns a data.frame containing available resources within a repository
    - all or filtered by file type or those within a specific network or within a specific repository
    - optional filtering of meta information for a given string
