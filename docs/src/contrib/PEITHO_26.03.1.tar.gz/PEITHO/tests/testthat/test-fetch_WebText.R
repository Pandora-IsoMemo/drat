test_that("fetch_WebText returns valid WebText object for example.com", {
  obj <- fetch_WebText("https://httpbin.org/html", return_text_blocks_only = FALSE)
  expect_true(is_WebText(obj))
  expect_equal(obj$url, "https://httpbin.org/html")
  expect_type(obj$text, "character")
  expect_s3_class(obj, "WebText")
  expect_true(obj$status_code >= 200)
  expect_type(obj$warnings, "character")
})

test_that("fetch_WebText handles invalid URL gracefully", {
  expect_error(
    fetch_WebText(
      "http://nonexistent.domain.example",
      return_text_blocks_only = FALSE
    )
  )
})

test_that("fetch_WebText can return text blocks only", {
  text_blocks <- fetch_WebText(
    "https://httpbin.org/html",
    return_text_blocks_only = TRUE
  )
  expect_type(text_blocks, "character")
  expect_true(length(text_blocks) > 0)
})
