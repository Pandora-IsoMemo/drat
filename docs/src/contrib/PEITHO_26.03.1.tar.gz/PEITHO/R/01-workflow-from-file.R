# Helper functions for workflow extraction from files

normalize_varname <- function(x) {
  x <- trimws(x)
  gsub(" ", "_", x)
}

extract_tag_varname <- function(x, pattern) {
  varname <- sub(pattern, "\\1", x)
  normalize_varname(varname)
}

read_json_if_exists <- function(path) {
  if (!file.exists(path)) return(list())
  jsonlite::fromJSON(path, simplifyVector = FALSE)
}

load_inputs_to_list <- function(
  input_path,
  pattern = "@#\\*I\\*#@"
) {
  # load input.json or input.txt
  if (grepl("\\.json$", input_path)) {
    # load input.json
    input_list <- read_json_if_exists(input_path)
  } else if (grepl("\\.txt$", input_path)) {
    # load input.txt
    if (file.exists(input_path)) {
      lines <- readLines(input_path)
      tag_list_indx <- grepl(paste0("^", pattern, ".*", pattern, "$"), lines)
      tag_list <- unique(lines[tag_list_indx])
      # for all tags find lines in between and store as list
      input_list <- list()
      for (tag in tag_list) {
        start_indx <- which(lines == tag)[1] + 1
        end_indx <- which(lines == tag)[2] - 1
        if (is.na(end_indx)) {
          end_indx <- length(lines)
        }
        # get variable name
        varname <- extract_tag_varname(tag, paste0("^", pattern, "(.*)", pattern, "$"))
        # get value in between tags and store in list
        input_list[[varname]] <- paste(lines[start_indx:end_indx], collapse = "\n")
      }
    } else {
      input_list <- list()
    }
  } else {
    stop(
      "Unsupported input file format: ", input_path,
      call. = FALSE
    )
  }

  input_list
}

is_input_tag <- function(x) {
  grepl("^@#\\*I\\*#@.*@#\\*I\\*#@$", x)
}

is_result_tag <- function(x) {
  grepl("^@#\\*L\\*#@.*@#\\*L\\*#@$", x)
}

make_param_from_arg <- function(
  arg,
  arg_name,
  step_i,
  arg_i,
  cmd_loop,
  input_list
) {
  if (!nzchar(arg_name)) arg_name <- NULL

  if (is_input_tag(arg)) {
    varname <- extract_tag_varname(arg, "^@#\\*I\\*#@(.*)@#\\*I\\*#@$")

    # if (!varname %in% names(input_list)) {
    #   stop(
    #     "Input variable '", varname, "' not found in input file.",
    #     call. = FALSE
    #   )
    # }
    new_operationparam(
      step_id = step_i,
      position = arg_i,
      name     = arg_name,
      value    = input_list[[varname]] %||% NULL,
      type     = "input",
      label    = varname,
      loop     = cmd_loop %||% "no"
    )
  } else if (is_result_tag(arg)) {
    varname <- extract_tag_varname(arg, "^@#\\*L\\*#@(.*)@#\\*L\\*#@$")

    new_operationparam(
      step_id = step_i,
      position = arg_i,
      name     = arg_name,
      value    = NULL,
      type     = "result",
      label    = varname,
      loop     = cmd_loop %||% "no"
    )
  } else {
    # literal without name (no tag)
    new_operationparam(
      step_id = step_i,
      position = arg_i,
      name     = arg_name,
      value    = strip_outer_quotes(arg),
      type     = "literal",
      loop     = cmd_loop %||% "no"
    )
  }
}

parse_args <- function(arg_string) {
  if (is.null(arg_string) || !nzchar(arg_string)) {
    return(list(values = character(0), names = character(0)))
  }
  # split on commas, but not inside single or double quotes
  args_vec <- strsplit(
    arg_string,
    ",(?=(?:[^']*'[^']*')*[^']*$)(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)",
    perl = TRUE
  )[[1]] |> trimws()

  arg_names <- character(length(args_vec))
  arg_values <- character(length(args_vec))
  for (i in seq_along(args_vec)) {
    x <- args_vec[[i]]
    if (grepl("=", x)) {
      x_split <- trimws(strsplit(x, "=", fixed = TRUE)[[1]])
      arg_names[i] <- x_split[[1]]
      arg_values[i]  <- x_split[[2]]
    } else {
      # positional / unnamed argument
      arg_names[i] <- ""
      arg_values[i]  <- x
    }
  }

  list(values = arg_values, names = arg_names)
}

strip_outer_quotes <- function(x) {
  x <- trimws(x)
  if (nchar(x) < 2L) return(x)

  first <- substr(x, 1L, 1L)
  last  <- substr(x, nchar(x), nchar(x))

  if (first == last && first %in% c("'", "\"")) {
    substr(x, 2L, nchar(x) - 1L)
  } else {
    x
  }
}

load_workflow_script_env <- function(script_path, parent_env, show_functions_path = TRUE) {
  if (is.null(script_path)) return(parent_env)
  if (!file.exists(script_path) || file.info(script_path)$size == 0) {
    info_msg <- sprintf(
      "Custom script file not found or is empty: %s. Using global environment for operations.",
      basename(script_path)
    )
    PEITHO:::logInfo("%s", info_msg)
    return(parent_env)
  }
  if (is_running_online()) {
    warn_msg <- sprintf(
      "Running online; skipping loading custom functions script: %s",
      basename(script_path)
    )
    PEITHO:::logWarn("%s", warn_msg)
    warning(warn_msg, immediate. = TRUE, call. = FALSE)
    return(parent_env)
  }
  if (show_functions_path) {
    PEITHO:::logInfo("Loading custom script for workflow: %s", script_path)
  }
  script_env <- new.env(parent = parent_env)
  sys.source(script_path, envir = script_env)
  return(script_env)
}

make_param_from_arg_loop <- function(args_string, loop, step_i, input_list) {
  parsed   <- parse_args(args_string)
  args_vec <- parsed$values
  args_names <- parsed$names

  # create params
  params <- vector("list", length(args_vec))
  for (arg_i in seq_along(args_vec)) {
    PEITHO:::logDebug("  Processing argument %d: %s", arg_i, args_vec[[arg_i]])

    params[[arg_i]] <- make_param_from_arg(
      arg      = args_vec[[arg_i]],
      arg_name = args_names[arg_i],
      arg_i    = arg_i,
      step_i   = step_i,
      cmd_loop = loop,
      input_list = input_list
    )
  }

  params
}

extract_input_list_from_files <- function(inputs_path) {
  # return empty wf if no inputs
  if (!file.exists(inputs_path)) {
    warn_msg <- sprintf(
      "%s not found in folder '%s'. Returning empty workflow.",
      basename(inputs_path),
      dirname(inputs_path)
    )
    PEITHO:::logWarn("%s", warn_msg)
    warning(warn_msg, immediate. = TRUE, call. = FALSE)
    return(list())
  }

  PEITHO:::logDebug("Loading inputs from %s", inputs_path)
  input_list <- load_inputs_to_list(inputs_path)

  input_list
}

parse_required_fields <- function(args_string) {
  args_values <- parse_args(args_string)$values

  list(
    inputs = unique(vapply(
      args_values[is_input_tag(args_values)],
      extract_tag_varname,
      FUN.VALUE = character(1),
      pattern = "^@#\\*I\\*#@(.*)@#\\*I\\*#@$"
    )),
    steps = unique(vapply(
      args_values[is_result_tag(args_values)],
      extract_tag_varname,
      FUN.VALUE = character(1),
      pattern = "^@#\\*L\\*#@(.*)@#\\*L\\*#@$"
    ))
  )
}

#' Extract workflow steps from files in a folder
#'
#' @param workflow_file_paths A list of file paths for workflow files (see `workflow_file_paths()`).
#'  Default is the package's `peitho_files` folder.
#' @param show_functions_path Logical, whether to show the path of the loaded script file.
#' @return A list of `workflowstep` objects.
#' @export
workflow_steps_from_files <- function(
  workflow_file_paths,
  show_functions_path = TRUE
) {
  # return empty wf if no commands
  if (!file.exists(workflow_file_paths$commands_path)) {
    warn_msg <- sprintf(
      "%s not found in folder '%s'. Returning empty workflow.",
      basename(workflow_file_paths$commands_path),
      workflow_file_paths$path_to_folder
    )
    PEITHO:::logWarn("%s", warn_msg)
    warning(warn_msg, immediate. = TRUE, call. = FALSE)
    return(list())
  }

  # create results file if not exists
  if (!file.exists(workflow_file_paths$results_path)) {
    PEITHO:::logInfo("Creating empty %s file.", basename(workflow_file_paths$results_path))
    jsonlite::write_json(
      list(),
      workflow_file_paths$results_path,
      auto_unbox = TRUE,
      pretty = TRUE
    )
  }

  # If the file exists and is not empty, load the functions file into a new environment that
  # inherits from the global environment.
  env <- load_workflow_script_env(
    script_path = workflow_file_paths$functions_path,
    parent_env = parent.frame(),
    show_functions_path = show_functions_path
  )

  PEITHO:::logDebug("Loading commands from %s", workflow_file_paths$commands_path)
  commands_list <- read_json_if_exists(path = workflow_file_paths$commands_path)

  PEITHO:::logDebug("Extracting %d workflow steps from commands", length(commands_list))
  steps <- lapply(seq_along(commands_list), function(step_i) {
    cmd <- commands_list[[step_i]]

    # create workflowstep
    new_workflowstep(
      entry           = step_i,
      name            = cmd$name %||% paste0("Step ", step_i),
      label           = cmd$label %||% cmd$name %||% paste0("Step ", step_i),
      comments        = cmd$comments %||% "",
      command         = cmd$command,
      args            = cmd$args %||% "",
      loop            = cmd$loop %||% "no",
      env             = env
    )
  })

  # return all steps as list
  steps
}
