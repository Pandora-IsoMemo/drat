# InquiryR 24.11.0

## New Features
- First version of the shiny app containing an example inquiry template.
