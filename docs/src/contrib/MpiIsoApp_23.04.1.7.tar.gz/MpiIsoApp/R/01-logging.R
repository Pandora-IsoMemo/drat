logging <- function(msg, ...) {
  futile.logger::flog.info(msg, ...)
}