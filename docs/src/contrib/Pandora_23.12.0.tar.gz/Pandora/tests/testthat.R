library(testthat)
library(Pandora)

test_check("Pandora")