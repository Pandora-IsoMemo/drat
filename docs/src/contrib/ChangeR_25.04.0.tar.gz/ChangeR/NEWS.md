# ChangeR 25.04.0

## New Features
- option to add custom points to the model plot

## Updates
- reduce package size by adding example files to the `.Rbuildignore`

# ChangeR 24.11.0

## New Features
- first version of the shiny app for change-point detection based on modules extracted from OsteoBioR 24.10.0 (#1)
