settings <- modules::module({
  modules::export("pathToSavedModels")
  
  pathToSavedModels <- "./predefinedModels"
})
