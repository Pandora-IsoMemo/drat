test_that("loading css works", {
  expect_silent(includeShinyToolsCSS())
})
