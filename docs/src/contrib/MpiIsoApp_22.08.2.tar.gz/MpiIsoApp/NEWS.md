# MpiIsoApp development version

# MpiIsoApp 22.08.1

## Enhancements
- when using _Pandora_ skin: updates of the UI in the _Import Data_ pop-up menu (#39)
- update label names in the _maps_ tab (#48)

## Bug fixes

- fixes in the modelling tab _AssignR_: (#46)
