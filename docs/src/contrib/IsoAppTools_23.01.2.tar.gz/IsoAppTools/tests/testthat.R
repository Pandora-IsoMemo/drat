library(testthat)
library(IsoAppTools)

test_check("IsoAppTools")
