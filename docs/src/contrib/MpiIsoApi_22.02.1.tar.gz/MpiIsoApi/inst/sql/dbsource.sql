SELECT DISTINCT `source` AS `dbsource` FROM data;
