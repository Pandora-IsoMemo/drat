select max(`timestamp`) as `lastUpdate` from `updated`;
