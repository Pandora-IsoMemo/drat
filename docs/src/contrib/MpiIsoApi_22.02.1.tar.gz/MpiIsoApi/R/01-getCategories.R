getCategories <- function(){
  # Later: Get this information from db
  c(
    "Sample description",
    "Isotopic proxies",
    "Location"
  )
}
