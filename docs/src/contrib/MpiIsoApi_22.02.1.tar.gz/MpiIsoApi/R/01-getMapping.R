getMapping <- function() {
  Result(list(), mapping = sendQueryCache("mapping"))
}
