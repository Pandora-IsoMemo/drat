DELETE FROM {{ tableName }} WHERE `mappingId` = {{ mappingId }} AND `source` = {{ dbSource }};
