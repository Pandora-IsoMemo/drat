DELETE FROM `mapping` WHERE `mappingId` = {{ mappingId }};
