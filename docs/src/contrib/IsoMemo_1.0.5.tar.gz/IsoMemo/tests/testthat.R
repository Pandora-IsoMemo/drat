library(testthat)
library(IsoMemo)

test_check("IsoMemo")
