library(testthat)
library(OsteoBioR)

test_check("OsteoBioR")
