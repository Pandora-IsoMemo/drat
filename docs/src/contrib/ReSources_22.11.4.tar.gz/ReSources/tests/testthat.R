library(testthat)
library(ReSources)

test_check("ReSources")
