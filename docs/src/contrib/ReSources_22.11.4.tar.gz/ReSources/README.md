# ReSources

### Access to online version:
- MAIN version: https://isomemoapp.com/app/resources

### Folder with example models
- `inst/app/predefinedModels`

### Help and installation Instructions:
- https://github.com/Pandora-IsoMemo/resources/wiki

### Release Notes:
- see `NEWS.md`
