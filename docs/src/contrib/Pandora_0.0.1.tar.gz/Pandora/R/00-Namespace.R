#' @importFrom httr content GET timeout
#' @importFrom magrittr %>% 
#' @importFrom shiny isRunning withProgress
#' @importFrom stats setNames
NULL