library(testthat)
library(DataTools)

test_check("DataTools")
