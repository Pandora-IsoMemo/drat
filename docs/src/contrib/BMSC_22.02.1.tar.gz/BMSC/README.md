# BMSC (constraint-estimation)

## Installation on local machine:
- consider requirements.txt 
- in R-studio, install.packages('rstan') may be used
- Access beta version: https://isomemoapp.com/app/constraint-estimation-app-beta
