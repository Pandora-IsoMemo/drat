library(testthat)
library(BMSCS)

test_check("BMSCS")
