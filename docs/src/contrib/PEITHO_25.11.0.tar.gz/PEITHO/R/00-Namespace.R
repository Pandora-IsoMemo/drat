#' @rawNamespace import(shiny)

utils::globalVariables(
  c()
)

#' @importFrom httr2 request req_perform req_timeout req_user_agent resp_status resp_body_html
#' @importFrom rvest html_element html_elements html_text2
#' @importFrom stringr str_squish
#' @importFrom tibble tibble
NULL
