library(testthat)
library(MpiIsoApi)

test_check("MpiIsoApi")
