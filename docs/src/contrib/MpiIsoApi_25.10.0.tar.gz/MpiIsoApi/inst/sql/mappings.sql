SELECT distinct(`mappingId`) as `dbmappings` from `mapping`;
