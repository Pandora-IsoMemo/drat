library(testthat)
library(BMSC)

test_check("BMSC")
