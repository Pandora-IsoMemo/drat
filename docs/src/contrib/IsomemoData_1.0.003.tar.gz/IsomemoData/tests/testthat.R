library(testthat)
library(IsomemoData)

test_check("IsomemoData")
