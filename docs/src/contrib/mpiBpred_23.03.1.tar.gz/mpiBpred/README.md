# Bpred App

### Access to online version:
- MAIN version: https://isomemoapp.com/app/bpred

### Help and installation instructions:
- https://github.com/Pandora-IsoMemo/bpred/wiki

### Release notes:
- see `NEWS.md`

### Folder for remote models
- [`inst/app/predefinedModels`](https://github.com/Pandora-IsoMemo/bpred/tree/main/inst/app/predefinedModels)
