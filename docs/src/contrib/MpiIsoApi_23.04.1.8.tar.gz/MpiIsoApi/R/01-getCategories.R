getCategories <- function(mappingId = "IsoMemo"){
  # Later: Get this information from db
  c(
    "Sample description",
    "Isotopic proxies",
    "Location"
  )
}
