# BMSC App (constraint-estimation-app)

### Access to online version:
- BETA version: https://isomemoapp.com/app/bmsc-beta

### Help and installation instructions:
- https://github.com/Pandora-IsoMemo/bmsc-app/wiki
