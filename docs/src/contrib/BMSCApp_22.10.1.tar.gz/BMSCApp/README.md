# BMSC App (constraint-estimation-app)

### Access to online version:
- MAIN version: https://isomemoapp.com/app/bmsc
- BETA version: https://isomemoapp.com/app/bmsc-beta

### Help and installation instructions:
- https://github.com/Pandora-IsoMemo/bmsc-app/wiki

### Folder for online models
- `inst/app/predefinedModels`
