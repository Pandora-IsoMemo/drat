An app around oxcAAR package.
