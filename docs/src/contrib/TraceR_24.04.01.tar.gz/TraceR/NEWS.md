# TraceR 24.04.1

## New Features

- add NEWS file
- add Pkgdown documentation workflow
- add R-cmd check workflow


# TraceR 23.11.1

## New Features

- first draft of TraceR

