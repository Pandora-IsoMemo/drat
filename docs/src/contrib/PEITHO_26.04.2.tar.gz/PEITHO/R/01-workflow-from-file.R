# Helper functions for workflow extraction from files

normalize_varname <- function(x) {
  x <- trimws(x)

  # Keep selector semantics in optional trailing [...] by removing whitespace
  # there, while normalizing label spaces to underscores.
  has_selector <- grepl("\\[[^\\]]*\\]$", x, perl = TRUE)
  selector <- ifelse(
    has_selector,
    sub("^.*(\\[[^\\]]*\\])$", "\\1", x, perl = TRUE),
    ""
  )
  base <- ifelse(has_selector, sub("\\[[^\\]]*\\]$", "", x, perl = TRUE), x)

  base <- gsub(" ", "_", base)
  selector <- gsub("\\s+", "", selector, perl = TRUE)

  paste0(base, selector)
}

normalize_name_part <- function(x) {
  gsub(" ", "_", trimws(x))
}

extract_result_ref <- function(x) {
  m <- regexec(result_pattern(), x, perl = TRUE)
  captures <- regmatches(x, m)[[1]]

  if (!length(captures)) {
    stop("Invalid result tag reference: ", x, call. = FALSE)
  }

  label <- normalize_name_part(captures[[2]])
  selector <- NULL

  if (length(captures) >= 3L && nzchar(captures[[3]])) {
    selector <- gsub("\\s+", "", captures[[3]], perl = TRUE)
    if (grepl("^\\[\\[.*\\]\\]$", selector)) {
      selector <- substr(selector, 3L, nchar(selector) - 2L)
    } else {
      selector <- substr(selector, 2L, nchar(selector) - 1L)
    }
  }

  list(label = label, selector = selector)
}

extract_tag_varname <- function(x, pattern) {
  varname <- sub(pattern, "\\1\\2", x, perl = TRUE)
  normalize_varname(varname)
}

read_json_if_exists <- function(path) {
  if (!file_nonempty(path)) return(list())
  jsonlite::fromJSON(path, simplifyVector = FALSE)
}

load_inputs_to_list <- function(
  input_path,
  pattern = "@#\\*I\\*#@"
) {
  # load input.json or input.txt
  if (grepl("\\.json$", input_path)) {
    # load input.json
    input_list <- read_json_if_exists(input_path)
  } else if (grepl("\\.txt$", input_path)) {
    # load input.txt
    if (file_nonempty(input_path)) {
      lines <- readLines(input_path)
      tag_list_indx <- grepl(paste0("^", pattern, ".*", pattern, "$"), lines)
      tag_list <- unique(lines[tag_list_indx])
      # for all tags find lines in between and store as list
      input_list <- list()
      for (tag in tag_list) {
        start_indx <- which(lines == tag)[1] + 1
        end_indx <- which(lines == tag)[2] - 1
        if (is.na(end_indx)) {
          end_indx <- length(lines)
        }
        # get variable name
        varname <- extract_tag_varname(tag, paste0("^", pattern, "(.*)", pattern, "$"))
        # get value in between tags and store in list
        input_list[[varname]] <- paste(lines[start_indx:end_indx], collapse = "\n")
      }
    } else {
      input_list <- list()
    }
  } else {
    stop(
      "Unsupported input file format: ", input_path,
      call. = FALSE
    )
  }

  input_list
}

input_pattern <- function() "^@#\\*I\\*#@((?:(?!@#\\*I\\*#@).)*)@#\\*I\\*#@$"
result_pattern <- function() "^@#\\*L\\*#@((?:(?!@#\\*L\\*#@).)*)@#\\*L\\*#@((?:\\[\\[[^\\]]+\\]\\])|(?:\\[[^\\]]+\\]))?$"

is_input_tag <- function(x) {
  grepl(input_pattern(), x, perl = TRUE)
}

is_result_tag <- function(x) {
  grepl(result_pattern(), x, perl = TRUE)
}

make_param_from_arg <- function(
  arg,
  arg_name,
  step_i,
  arg_i,
  cmd_loop,
  input_list
) {
  if (!nzchar(arg_name)) arg_name <- NULL
  selector <- NULL

  if (is_input_tag(arg)) {
    type <- "input"
    label <- extract_tag_varname(arg, input_pattern())
    value <- input_list[[label]] %||% NULL
  } else if (is_result_tag(arg)) {
    result_ref <- extract_result_ref(arg)
    type <- "result"
    label <- result_ref$label
    selector <- result_ref$selector
    value <- NULL
  } else {
    # literal without name (no tag)
    type <- "literal"
    label <- ""
    value <- strip_outer_quotes(arg)
  }

  new_operationparam(
    step_id = step_i,
    position = arg_i,
    name     = arg_name,
    value    = value,
    type     = type,
    label    = label,
    loop     = cmd_loop %||% "no",
    selector = selector %||% NULL
  )
}

parse_args <- function(arg_string) {
  if (is.null(arg_string) || !nzchar(arg_string)) {
    return(list(values = character(0), names = character(0)))
  }

  split_top_level_args <- function(x) {
    chars <- strsplit(x, "", fixed = TRUE)[[1]]
    if (!length(chars)) return(character(0))

    parts <- character(0)
    current <- ""
    in_single <- FALSE
    in_double <- FALSE
    bracket_depth <- 0L
    paren_depth <- 0L

    for (ch in chars) {
      if (ch == "'" && !in_double) {
        in_single <- !in_single
        current <- paste0(current, ch)
        next
      }

      if (ch == "\"" && !in_single) {
        in_double <- !in_double
        current <- paste0(current, ch)
        next
      }

      if (!in_single && !in_double) {
        if (ch == "[") {
          bracket_depth <- bracket_depth + 1L
          current <- paste0(current, ch)
          next
        }
        if (ch == "]") {
          bracket_depth <- max(0L, bracket_depth - 1L)
          current <- paste0(current, ch)
          next
        }
        if (ch == "(") {
          paren_depth <- paren_depth + 1L
          current <- paste0(current, ch)
          next
        }
        if (ch == ")") {
          paren_depth <- max(0L, paren_depth - 1L)
          current <- paste0(current, ch)
          next
        }

        if (ch == "," && bracket_depth == 0L && paren_depth == 0L) {
          parts <- c(parts, trimws(current))
          current <- ""
          next
        }
      }

      current <- paste0(current, ch)
    }

    c(parts, trimws(current))
  }

  args_vec <- split_top_level_args(arg_string)
  args_vec <- args_vec[nzchar(args_vec)]

  arg_names <- character(length(args_vec))
  arg_values <- character(length(args_vec))
  for (i in seq_along(args_vec)) {
    x <- args_vec[[i]]
    if (grepl("=", x)) {
      x_split <- trimws(strsplit(x, "=", fixed = TRUE)[[1]])
      arg_names[i] <- x_split[[1]]
      arg_values[i]  <- x_split[[2]]
    } else {
      # positional / unnamed argument
      arg_names[i] <- ""
      arg_values[i]  <- x
    }
  }

  list(values = arg_values, names = arg_names)
}

strip_outer_quotes <- function(x) {
  x <- trimws(x)
  if (nchar(x) < 2L) return(x)

  first <- substr(x, 1L, 1L)
  last  <- substr(x, nchar(x), nchar(x))

  if (first == last && first %in% c("'", "\"")) {
    substr(x, 2L, nchar(x) - 1L)
  } else {
    x
  }
}

load_workflow_script_env <- function(script_path, parent_env, show_functions_path = TRUE) {
  if (is.null(script_path)) return(parent_env)
  if (!file_nonempty(script_path)) {
    info_msg <- sprintf(
      "Custom script file not found or is empty: %s. Using global environment for operations.",
      basename(script_path)
    )
    PEITHO:::logInfo("%s", info_msg)
    return(parent_env)
  }
  if (is_running_online()) {
    warn_msg <- sprintf(
      "Running online; skipping loading custom functions script: %s",
      basename(script_path)
    )
    PEITHO:::logWarn("%s", warn_msg)
    warning(warn_msg, immediate. = TRUE, call. = FALSE)
    return(parent_env)
  }
  if (show_functions_path) {
    PEITHO:::logInfo("Loading custom script for workflow: %s", script_path)
  }
  script_env <- new.env(parent = parent_env)
  
  tryCatch(
    sys.source(script_path, envir = script_env),
    error = function(e) {
      err_msg <- sprintf(
        "Error loading custom functions from %s: %s",
        basename(script_path),
        conditionMessage(e)
      )
      PEITHO:::logError("%s", err_msg)
      stop(err_msg, call. = FALSE)
    }
  )
  
  return(script_env)
}

make_param_from_arg_loop <- function(args_string, loop, step_i, input_list) {
  parsed   <- parse_args(args_string)
  args_vec <- parsed$values
  args_names <- parsed$names

  # create params
  params <- vector("list", length(args_vec))
  for (arg_i in seq_along(args_vec)) {
    PEITHO:::logDebug("  Processing argument %d: %s", arg_i, args_vec[[arg_i]])

    params[[arg_i]] <- make_param_from_arg(
      arg      = args_vec[[arg_i]],
      arg_name = args_names[arg_i],
      arg_i    = arg_i,
      step_i   = step_i,
      cmd_loop = loop,
      input_list = input_list
    )
  }

  params
}

extract_input_list_from_files <- function(inputs_path) {
  # return empty wf if no inputs
  if (!file_nonempty(inputs_path)) {
    warn_msg <- sprintf(
      "%s not found or is empty in folder '%s'. Returning empty input list.",
      basename(inputs_path),
      dirname(inputs_path)
    )
    PEITHO:::logWarn("%s", warn_msg)
    warning(warn_msg, immediate. = TRUE, call. = FALSE)
    return(list())
  }

  PEITHO:::logDebug("Loading inputs from %s", inputs_path)
  input_list <- load_inputs_to_list(inputs_path)

  input_list
}

parse_required_fields <- function(args_string) {
  args_values <- parse_args(args_string)$values
  result_args <- args_values[is_result_tag(args_values)]

  list(
    inputs = unique(vapply(
      args_values[is_input_tag(args_values)],
      extract_tag_varname,
      FUN.VALUE = character(1),
      pattern = input_pattern()
    )),
    steps = unique(vapply(
      result_args,
      function(x) extract_result_ref(x)$label,
      FUN.VALUE = character(1)
    ))
  )
}

#' Extract workflow steps from files in a folder
#'
#' @param workflow_file_paths A list of file paths for workflow files (see `workflow_file_paths()`).
#'  Default is the package's `peitho_files` folder.
#' @param show_functions_path Logical, whether to show the path of the loaded script file.
#' @return A list of `workflowstep` objects.
#' @export
workflow_steps_from_files <- function(
  workflow_file_paths,
  show_functions_path = TRUE
) {
  # return empty wf if no commands
  if (!file_nonempty(workflow_file_paths$commands_path)) {
    warn_msg <- sprintf(
      "%s not found or is empty in folder '%s'. Returning empty workflow.",
      basename(workflow_file_paths$commands_path),
      workflow_file_paths$path_to_folder
    )
    PEITHO:::logWarn("%s", warn_msg)
    warning(warn_msg, immediate. = TRUE, call. = FALSE)
    return(list())
  }

  # create results file if not exists
  if (!file_nonempty(workflow_file_paths$results_path)) {
    PEITHO:::logInfo(
      "Creating empty %s file.",
      basename(workflow_file_paths$results_path)
    )
    jsonlite::write_json(
      list(),
      workflow_file_paths$results_path,
      auto_unbox = TRUE,
      pretty = TRUE
    )
  }

  # If the file exists and is not empty, load the functions file into a new environment that
  # inherits from the global environment.
  env <- load_workflow_script_env(
    script_path = workflow_file_paths$functions_path,
    parent_env = parent.frame(),
    show_functions_path = show_functions_path
  )

  PEITHO:::logDebug("Loading commands from %s", workflow_file_paths$commands_path)
  commands_list <- read_json_if_exists(path = workflow_file_paths$commands_path)

  PEITHO:::logDebug("Extracting %d workflow steps from commands", length(commands_list))
  steps <- lapply(seq_along(commands_list), function(step_i) {
    cmd <- commands_list[[step_i]]

    # create workflowstep
    new_workflowstep(
      entry           = step_i,
      name            = cmd$name %||% paste0("Step ", step_i),
      label           = cmd$label %||% cmd$name %||% paste0("Step ", step_i),
      comments        = cmd$comments %||% "",
      command         = cmd$command,
      args            = cmd$args %||% "",
      loop            = cmd$loop %||% "no",
      env             = env
    )
  })

  # return all steps as list
  steps
}
