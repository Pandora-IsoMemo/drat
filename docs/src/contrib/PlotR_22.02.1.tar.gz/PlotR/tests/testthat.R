library(testthat)
library(PlotR)

test_check("PlotR")
