library(testthat)
library(DSSM)

test_check("DSSM")
