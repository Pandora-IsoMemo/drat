# PlotR

<!-- badges: start -->
[![R-CMD-check](https://github.com/Pandora-IsoMemo/PlotR/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/Pandora-IsoMemo/PlotR/actions/workflows/R-CMD-check.yaml)
<!-- badges: end --

### Access to online version:
- MAIN version: https://isomemoapp.com/app/plotr
- BETA version: https://isomemoapp.com/app/plotr-beta

### Help and installation instructions:
- https://github.com/Pandora-IsoMemo/plotr/wiki

### Release notes:
- see `NEWS.md`

### Folder for online models
- [`inst/app/predefinedModels`](https://github.com/Pandora-IsoMemo/plotr/tree/main/inst/app/predefinedModels)
