startApplication()
