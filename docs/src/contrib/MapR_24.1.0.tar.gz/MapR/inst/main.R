devtools::load_all()

startApplication(launch.browser = TRUE)

