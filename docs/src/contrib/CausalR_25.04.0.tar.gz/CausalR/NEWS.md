# CausalR 25.04.0

## Updates
- reduce package size by adding example files to the `.Rbuildignore`
- remove warning from import module

# CausalR 24.06.1

## New Features
- Documentation for package functions has been added.

# CausalR 24.06.0

## New Features
- The Shiny app has been refactored into a package, enabling the app to be launched within a Docker container.
- Dependencies on other packages have been defined.
