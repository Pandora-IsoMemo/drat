library(testthat)
library(CausalR)  # Replace with the name of your app's package (or source your R scripts)
test_check("CausalR")  # Replace with the package or project name
