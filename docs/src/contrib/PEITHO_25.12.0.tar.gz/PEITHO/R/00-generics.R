update <- function(object, steprun, idx, ...) {
  UseMethod("update")
}

run <- function(object, state, ...) {
  UseMethod("run")
}