.onLoad <- function(libname, pkgname) {
  init_logging()
}