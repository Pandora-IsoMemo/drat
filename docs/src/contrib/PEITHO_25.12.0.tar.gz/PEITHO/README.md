# PEITHO

<!-- badges: start -->
[![R-CMD-check](https://github.com/Pandora-IsoMemo/PEITHO/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/Pandora-IsoMemo/PEITHO/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

[See the latest release notes in NEWS.md](./NEWS.md)